# -*- coding: utf-8 -*-
"""chap001.ipynb

# 第1章 データ分析って何？

## 03 Notebookの準備をしよう

リスト1.1
"""

print("Hello")

"""リスト1.2"""

import matplotlib.pyplot as plt
plt.plot([0,2,1,3])
plt.show()