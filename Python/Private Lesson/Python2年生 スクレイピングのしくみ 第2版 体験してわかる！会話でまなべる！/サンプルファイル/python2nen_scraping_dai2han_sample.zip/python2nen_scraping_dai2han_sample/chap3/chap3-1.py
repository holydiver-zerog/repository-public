import pandas as pd

# CSVファイルを読み込む
df = pd.read_csv("test.csv")
print(df)
