key1 = "晴れ"
key2 = "曇り"

ans = f"今日は{key1}です。明日は{key2}です。"
print(ans)
