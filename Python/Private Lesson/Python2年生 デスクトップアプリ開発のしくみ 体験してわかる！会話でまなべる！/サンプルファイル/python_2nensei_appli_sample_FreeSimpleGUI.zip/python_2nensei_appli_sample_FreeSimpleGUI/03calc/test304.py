a = 123
b = 255
c = 65535
print(f" 2進数:a={a:#b} b={b:#b} c={c:#b}")
print(f"16進数:a={a:#x} b={b:#x} c={c:#x}")