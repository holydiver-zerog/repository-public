in1 = 1000
in2 = 4
txt = f"1人、{in1 / in2 :.2f}円です。"
print(txt)