a = "富士山"
b = 3776
txt = f"{a}の高さは、{b}mです。"
print(txt)