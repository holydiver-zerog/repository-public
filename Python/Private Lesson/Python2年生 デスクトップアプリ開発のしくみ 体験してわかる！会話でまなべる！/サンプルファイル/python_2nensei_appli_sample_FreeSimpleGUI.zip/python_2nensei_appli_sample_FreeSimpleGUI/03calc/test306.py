in1 = 1.60
in2 = 60
bmi = in2 / (in1 * in1)
txt = f"BMI値は、{bmi:.2f}です。"
print(txt)
