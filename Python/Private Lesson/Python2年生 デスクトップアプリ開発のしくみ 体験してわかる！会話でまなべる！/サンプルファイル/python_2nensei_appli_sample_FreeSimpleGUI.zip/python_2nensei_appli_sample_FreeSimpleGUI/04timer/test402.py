import datetime

start = datetime.datetime.now()
input("Enterキーを押してください")
now = datetime.datetime.now()
td = now - start
print(td)