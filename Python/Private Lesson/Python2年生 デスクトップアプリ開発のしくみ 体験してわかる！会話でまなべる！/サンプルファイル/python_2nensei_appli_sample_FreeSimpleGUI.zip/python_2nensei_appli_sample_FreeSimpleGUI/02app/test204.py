import FreeSimpleGUI as sg
sg.theme_previewer()
