num = 100 + 200
print(num)